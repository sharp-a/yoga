from yoga import *

schedule_rassylki()