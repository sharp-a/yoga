import telebot
import sqlite3
import requests
import json
from telebot import types, callback_data
import csv
import time
import schedule

bitrix1 = requests.get('https://b24-tbhvme.bitrix24.kz/rest/1/xmi7ldb71z7eq6ma/humanresources.hcmlink.employee.list.json')
employees = json.loads(bitrix1.text)

bot = telebot.TeleBot('токен телеграм бота из botfather')

@bot.message_handler(commands=['start'])
def start(message):
    bot.send_message(message.chat.id, 'Пожалуйста, введите ваш корпоративный e-mail для идентификации.')

    conn = sqlite3.connect('users.sql')
    cur = conn.cursor()

    cur.execute('CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, email varchar(50), user_id int, tg_id int)')
    conn.commit()
    cur.close()
    conn.close()
    bot.register_next_step_handler(message, registration)


def registration(message):
    email = message.text.strip()
    tg_id = message.from_user.id
    user_id = None
    for employee in employees['result']:
        if employee['EMAIL'] == email:
            user_id = employee['ID']
            bot.send_message(message.chat.id, 'Вы успешно прошли регистрацию в боте!\n\nВ <b>9:00</b> по <b>вторникам</b> и <b>четвергам</b> в этот чат с ботом будет приходить опросник пойдёте ли вы на йогу в 13:00 (лимит 15 мест)', parse_mode='html')
            break
    else:
        bot.send_message(message.chat.id, 'Неверный корпоративный e-mail. Попробуйте снова')
        bot.register_next_step_handler(message, registration)

    conn = sqlite3.connect('users.sql')
    cur = conn.cursor()

    if user_id:
        cur.execute(f'INSERT INTO users (email, user_id, tg_id) VALUES ("{email}", "{user_id}", "{tg_id}")')
        conn.commit()

    cur.close()
    conn.close()


def rassylka():
    conn = sqlite3.connect('users.sql')
    cur = conn.cursor()

    cur.execute('SELECT tg_id FROM users')
    tg_ids = cur.fetchall()
    tg_rassylka = [tg_id[0] for tg_id in tg_ids]
    cur.close()
    conn.close()

    for i in tg_rassylka:
        markup = types.InlineKeyboardMarkup()
        btn1 = types.InlineKeyboardButton('Да', callback_data='reserve')
        btn2 = types.InlineKeyboardButton('Нет', callback_data='refuse')
        markup.row(btn1, btn2)
        bot.send_message(i, 'Запись на йогу сегодня в 9:00 (лимит 15 мест)\n\n<b>Вы идёте?</b>', parse_mode='html', reply_markup=markup)

def rassylka_limit():
    conn = sqlite3.connect('users.sql')
    cur = conn.cursor()

    cur.execute('SELECT tg_id FROM users')
    tg_ids = cur.fetchall()
    tg_rassylka = [tg_id[0] for tg_id in tg_ids]
    cur.close()
    conn.close()

    time.sleep(5)
    for i in tg_rassylka:
        bot.send_message(i, '<b>Места на сегодня закончились!</b>', parse_mode='html')



@bot.callback_query_handler(func=lambda callback: True)
def callback_message(callback):
    if callback.data == 'reserve':
        check_existence(callback)
    elif callback.data == 'refuse':
        bot.edit_message_text('<b>Можете зарегистрироваться в следующий раз!</b>', callback.message.chat.id, callback.message.message_id, parse_mode='html')

def check_existence(callback):
    responses = 'responses.csv'
    try:
        with open(responses, 'r') as file:
            button_limit(responses, callback)
    except FileNotFoundError:
        with open(responses, 'w') as file:
            pass
        button_limit(responses, callback)
def button_limit(responses, callback):
    tg_id = callback.from_user.id
    with open(responses, 'r', newline='') as file:
        reader = csv.reader(file)
        rows = list(reader)
        if len(rows) < 1:
            conn = sqlite3.connect('users.sql')
            cur = conn.cursor()

            cur.execute(f'SELECT user_id FROM users WHERE tg_id = "{tg_id}"')
            result = cur.fetchone()

            conn.close()
            user_id = result[0]
            with open(responses, 'a', newline='') as file:
                writer = csv.writer(file)
                writer.writerow([user_id])
                bot.edit_message_text('<b>Вы зарегистрированы сегодня на йогу в 13:00✅</b>\n\n<b>Ожидаем ваше присутствие, так как вашу запись нельзя отменить❗️</b>', callback.message.chat.id, callback.message.message_id, parse_mode='html')
                bot.send_message(callback.message.chat.id, '✅')
        elif len(rows) == 1:
            conn = sqlite3.connect('users.sql')
            cur = conn.cursor()

            cur.execute(f'SELECT user_id FROM users WHERE tg_id = "{tg_id}"')
            result = cur.fetchone()

            conn.close()
            user_id = result[0]
            with open(responses, 'a', newline='') as file:
                writer = csv.writer(file)
                writer.writerow([user_id])
                bot.edit_message_text('<b>Вы зарегистрированы сегодня на йогу в 13:00✅</b>\n\n<b>Ожидаем ваше присутствие, так как вашу запись нельзя отменить❗️</b>', callback.message.chat.id, callback.message.message_id, parse_mode='html')
                bot.send_message(callback.message.chat.id, '✅')
                rassylka_limit()
        else:
            bot.edit_message_text('<b>Извиняемся, регистрация на сегодня уже закончена:( в другой раз!</b>', callback.message.chat.id, callback.message.message_id, parse_mode='html')


def schedule_rassylki():
    schedule.every().tuesday.at("09:00").do(rassylka)
    schedule.every().thursday.at("09:00").do(rassylka)
    schedule.every().tuesday.at("14:00").do(send_list)
    schedule.every().thursday.at("14:00").do(send_list)
    while True:
        schedule.run_pending()
def send_list():
    pass #здесь нужно расписать отправку responses.csv и его последующее удаление

def main():
    bot.infinity_polling()

if __name__ == '__main__':
    main()



